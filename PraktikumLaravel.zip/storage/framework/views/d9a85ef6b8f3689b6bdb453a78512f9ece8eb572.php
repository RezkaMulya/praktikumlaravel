

<?php $__env->startSection('content'); ?>



    <body> 
        <div class="container"> 
            <?php if(session('Sukses')): ?>
             <div class="alert alert-success" role="alert"> 
                <?php echo e(session('Sukses')); ?> 
            </div> <?php endif; ?>

            <h1 class="py-3">Edit Data Mahasiswa</h1>

            <div class="row"> 
                <form method="post" 
                action="/mahasiswa/<?php echo e($mahasiswa->id); ?>/update">

                <?php echo csrf_field(); ?>

                <div class="form-group mb-3"> 
                    <label for="exampleInputEmail1">Nama</label>
                    <input name="nama" type="text" class="form-control mt-2" id="exampleInputEmail1" aria-describedby="EmailHelp" placeholder="Nama Mahasiswa" value="<?php echo e($mahasiswa->nama); ?>">
                </div>

                <div class="form-group mb-3"> 
                    <label for="exampleInputEmail1">NIM</label> 
                    <input name="nim" type="text" class="form-control mt-2" id="exampleInputEmail1" aria-describedby="EmailHelp" placeholder="Nomor Induk Mahasiswa" value="<?php echo e($mahasiswa->nim); ?>"> 
                </div>

                <div class="form-group mb-3">
                    <label for="exampleFormControlTextarea1">Alamat</label>
                    <textarea name="alamat" class="form-control mt-2" id="exampleFormControlTextarea1" rows="3" placeholder="Alamat Mahasiswa"><?php echo e($mahasiswa->alamat); ?></textarea>
                </div>

                <div class="form-group mt-5"> 
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="/mahasiswa" class="btn btn-danger mx-3">Cancel</a> 
                </div>
            </form> 
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"> </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"> </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" cross origin="anonymous"> </script> 
    </body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PraktikumLaravel\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>